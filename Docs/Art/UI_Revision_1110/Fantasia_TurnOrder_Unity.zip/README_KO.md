# Fantasia · 턴 순서 애니메이션

왼쪽은 현재 턴, 오른쪽은 예정 턴입니다. 턴이 끝나면 기존 칸이 왼쪽으로 한 칸 이동하고, 다음 칸이 첫 위치에서 **122% 크기와 금빛 테두리**로 바뀝니다. 새 마지막 칸은 이동을 시작하기 전에 준비되어 오른쪽에서 동시에 들어옵니다.

- 정지 상태에는 8칸이 표시됩니다.
- 이동 시간은 0.42초입니다.
- 금빛 현재 턴 프레임과 청동색 일반 프레임은 제공된 원본 이미지의 해당 부분을 그대로 읽습니다.
- `Turn_Order_Preview.mp4`의 숫자는 이동 방향을 보여 주는 시연용 표시입니다.

## Unity에서 바로 확인하기

1. 압축을 풀고 `Assets > Import Package > Custom Package…`에서 `Fantasia_TurnOrder.unitypackage`를 가져옵니다.
2. 빈 테스트 씬에서 `Tools > Fantasia > Turn Order > Create Demo Canvas`를 선택합니다.
3. **Play**를 누르면 01 → 02 → 03 순으로 자동 재생됩니다.

Canvas의 기본 UI(uGUI)를 사용합니다. 실제 게임 씬에는 `Assets/FantasiaTurnOrder/Prefabs/TurnOrder.prefab`을 Canvas 아래에 넣습니다. 프리팹은 화면 상단 가운데를 기준으로 배치됩니다. Inspector의 **Build Scene Preview**를 누르면 Play 전에도 배치를 볼 수 있습니다. 양쪽 긴 판이 필요 없으면 **Show Side Panels**를 끕니다.

## 전투에서 연결하기

`TurnOrderTimeline`의 메서드 두 개를 호출하면 됩니다.

```csharp
// 전투 시작 또는 턴 순서를 새로 계산했을 때:
// 배열 0번이 현재 턴, 1번부터 다음 턴입니다.
turnOrder.SetQueue(visiblePortraits);

// 한 턴이 끝났을 때 한 번 호출:
// newFarRightPortrait는 새로 오른쪽 끝에 들어올 캐릭터의 Sprite입니다.
turnOrder.AdvanceTurn(newFarRightPortrait);
```

`turnOrder`는 `Fantasia.UI.TurnOrderTimeline` 컴포넌트입니다. `visiblePortraits`에는 왼쪽부터 최대 8개의 Sprite를 넣습니다. 실제 턴 순서는 전투 코드가 정하고, 이 컴포넌트는 받은 순서만 표시합니다. 연속 호출은 차례대로 재생됩니다. 초상화가 아직 없다면 **Placeholder Portrait**를 넣어 둘 수 있습니다. 초상화가 없어도 칸의 프레임은 유지됩니다. 이동 완료 시 **On Turn Settled** 이벤트가 한 번 호출됩니다.

## 포함된 파일

- `TurnOrder_Advance.anim`: 왼쪽 이동, 첫 칸 확대, 이전 칸 축소 키프레임.
- `TurnOrder_Idle.anim`: 정지 상태의 8칸 배치.
- `TurnOrder.controller`: Idle과 Advance 상태가 연결된 Animator Controller.
- `TurnOrder.prefab`: 게임 적용용.
- `TurnOrder_Demo.prefab`: 숫자로 움직임을 보여 주는 자동 재생 시연용.
- `TurnOrderTimeline.cs`: 초상화 연결, 새 칸 준비, 이동 후 순서 갱신.
- `Tools > Fantasia > Turn Order > Rebuild Default Clips`: 설치된 Unity에서 기본 클립을 다시 만드는 메뉴. 키를 직접 편집했다면 이 메뉴는 기본값으로 되돌립니다.

프리팹의 슬롯은 실행 시 만들어집니다. 클립 편집 전에 **Build Scene Preview**로 계층을 표시하세요. 배치와 확대의 타이밍을 맞추기 위해 기존 위치·크기 키의 끝 시간을 함께 조절합니다.

패키지의 자산 참조와 원본 이미지 일치 여부를 확인했습니다. 포함된 클립의 257개 시점에서 일반 칸 간격보다 큰 공백이 생기지 않는 것을 확인했습니다. 미리보기는 클립의 키프레임을 사용해 렌더링한 영상이며, 이 환경에서 실제 Unity Editor 컴파일과 Play Mode는 실행하지 않았습니다.
